"""Render the released HTML files as PDFs; no proof arithmetic is involved."""
from pathlib import Path
from weasyprint import HTML
O=Path(__file__).resolve().parent
for name in ("Illustrated_Guide", "Public_Paper", "Verification_Appendix"):
    p=O/("Pentagonal_Dual_Crystal_"+name+"_JA_v1.0.html")
    HTML(filename=str(p)).write_pdf(str(p.with_suffix(".pdf")))
